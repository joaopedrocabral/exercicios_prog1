#include <stdio.h>
#include <stdlib.h>

int main(){

    int i, num;
    
    for(i = 0; num >= 0; i++){
        printf("\nDIGITE UM NUMERO: ");
            scanf(" %d", &num);
    }

    printf("\nFORAM DIGITADOS %d NUMEROS!", i);


    return 0;
}