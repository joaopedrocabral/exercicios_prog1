#include <stdio.h>
#include <stdlib.h>

int main (){
    int i = 100;

    while(i>=1){
        printf("\nI = %d", i);
        --i;
    }
    return 0;
}