#include <stdio.h>
#include <stdlib.h>

int main (){
    int i;

    for(i = 2; i<=100; i+=2){
        printf("\n I = %d", i);
    }

    return 0;
}