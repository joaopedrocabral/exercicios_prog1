#include <stdio.h>
#include <stdlib.h>

int main(){
    int i = 100;

    while (i<=200) {
        printf("\nI = %d", i);
        i++;
    }

    return 0;
}