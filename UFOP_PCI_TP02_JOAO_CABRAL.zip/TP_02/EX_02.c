#include <stdio.h>
#include <stdlib.h>

int main (){

int i = 1;

while (i<=100){
    printf("\n I = %d", i);
    i++;
}

return 0;

}