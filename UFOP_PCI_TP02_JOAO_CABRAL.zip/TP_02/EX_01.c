#include <stdio.h>
#include <stdlib.h>

int main () {
    int i = 0;

    while (i<=50){
        printf("\ni = %d", i);
        i++;
    }

    return 0;
}