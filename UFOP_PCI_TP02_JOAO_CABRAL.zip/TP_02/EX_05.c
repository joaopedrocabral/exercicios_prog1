    #include <stdio.h>
    #include <stdlib.h>

    int main(){
        int i;

        for(i = 5; i<=500; i+=5){
            printf("\n I = %d", i);
        }

        return 0;
    }